import type {
  AuthorizationRequest,
  AuthorizationResponse,
  CancellationRequest,
  CancellationResponse,
  RefundRequest,
  RefundResponse,
  SettlementRequest,
  SettlementResponse,
} from '@vtex/payment-provider'
import {
  Cancellations,
  PaymentProvider,
  Refunds,
  Settlements,
  Authorizations,
} from '@vtex/payment-provider'
import type { VBase } from '@vtex/api'

import {
  getSecondsPassed,
  randomString,
  getPersistedSerialResponse,
  persistSerialResponse,
} from './utils'
import { executeAuthorization } from './flow'

const authorizationsBucket = 'authorizations'
const persistAuthorizationResponse = async (
  vbase: VBase,
  resp: AuthorizationResponse
) => vbase.saveJSON(authorizationsBucket, resp.paymentId, resp)

const getPersistedAuthorizationResponse = async (
  vbase: VBase,
  req: AuthorizationRequest
) =>
  vbase.getJSON<AuthorizationResponse | undefined>(
    authorizationsBucket,
    req.paymentId,
    true
  )

export default class FakePayIOConnector extends PaymentProvider {
  // This class needs modifications to pass the test suit.
  // Refer to https://help.vtex.com/en/tutorial/payment-provider-protocol#4-testing
  // in order to learn about the protocol and make the according changes.

  private async saveAndRetry(
    req: AuthorizationRequest,
    resp: AuthorizationResponse
  ) {
    await persistAuthorizationResponse(this.context.clients.vbase, resp)
    this.callback(req, resp)
  }

  public async authorize(
    authorization: AuthorizationRequest
  ): Promise<AuthorizationResponse> {
    if (this.isTestSuite) {
      const persistedResponse = await getPersistedAuthorizationResponse(
        this.context.clients.vbase,
        authorization
      )

      if (persistedResponse !== undefined && persistedResponse !== null) {
        return persistedResponse
      }

      return executeAuthorization(authorization, response =>
        this.saveAndRetry(authorization, response)
      )
    }

    // To redirect payment, use last name as "redirect"
    if (authorization.miniCart.buyer.lastName.toLowerCase() === 'redirect') {
      return Promise.resolve(
        Authorizations.redirect(authorization, {
          delayToCancel: 8400,
          paymentUrl: 'www.google.com',
          message: 'This payment needs to be redirected',
          redirectUrl: 'deprecated',
        })
      )
    }

    // To use 3DS2 payment flow, use last name as "3ds2"
    if (authorization.miniCart.buyer.lastName.toLowerCase() === '3ds2') {
      const { vbase } = this.context.clients

      const persistedResponse = await getPersistedAuthorizationResponse(
        vbase,
        authorization
      )

      /**
       * At the first try, return 'Authorizing' status
       * This is the payment app that is used in this flow:
       * https://github.com/vtex-apps/example-payment-authorization-app
       */
      if (persistedResponse === undefined || persistedResponse === null) {
        const payload = {
          approvePaymentUrl: authorization.callbackUrl,
          denyPaymentUrl: `https://${authorization.merchantName}.myvtex.com/_v/api/fake-pay-io/payments/${authorization.paymentId}/cancellations?an=${authorization.merchantName}`,
        }

        const response: AuthorizationResponse = await Promise.resolve(
          Authorizations.pending(authorization, {
            delayToCancel: 300000,
            paymentAppData: {
              appName: 'vtex.example-payment-auth-app',
              payload: JSON.stringify(payload),
            },
            message: 'The customer needs to finish the payment flow',
          })
        )

        persistAuthorizationResponse(vbase, response)

        return response
      }

      /**
       * At the second try, return 'Authorized'
       */
      return Promise.resolve(
        Authorizations.approve(authorization, {
          tid: randomString(),
          nsu: randomString(),
          authorizationId: randomString(),
          delayToAutoSettle: 60,
          message: 'Payment has been approved',
        })
      )
    }

    // To use Pagar.me payment flow, use last name as "pagarme"
    if (authorization.miniCart.buyer.lastName.toLowerCase() === 'pagarme') {
      const SECONDS_TO_WAIT = 30000
      const { vbase } = this.context.clients

      const persistedResponse = await getPersistedAuthorizationResponse(
        vbase,
        authorization
      )

      const persistedSerial = await getPersistedSerialResponse(
        vbase,
        authorization.paymentId
      )

      /**
       * At the first try, if there's no persistedResponse or if there's no serial sent, return vtex.pagarme-payment-app status and the serial number submitUrl at payload
       */
      if (persistedResponse === undefined || persistedResponse === null) {
        const payload = {
          submitUrl: `https://${authorization.merchantName}.myvtex.com/_v/api/fake-pay-io/payments/${authorization.paymentId}/serial-number?transactionId=${authorization.transactionId}`,
        }

        const response: AuthorizationResponse = await Promise.resolve(
          Authorizations.pending(authorization, {
            delayToCancel: SECONDS_TO_WAIT,
            paymentAppData: {
              appName: 'vtex.pagarme-payment-app',
              payload: JSON.stringify(payload),
            },
            message: 'vtex.pagarme-payment-app',
          })
        )

        persistAuthorizationResponse(vbase, response)

        return response
      }

      /**
       * if pass for the first condition and exists persistedResponse and persistedSerial, it will check if the time defined has passed. If true, return payment approved
       */
      if (
        persistedResponse &&
        persistedResponse.message === 'vtex.challenge-wait-for-confirmation' &&
        persistedSerial &&
        getSecondsPassed(persistedSerial.time) >= SECONDS_TO_WAIT
      ) {
        persistSerialResponse(vbase, null, authorization.paymentId)

        return Promise.resolve(
          Authorizations.approve(authorization, {
            tid: randomString(),
            nsu: randomString(),
            authorizationId: randomString(),
            delayToAutoSettle: 60,
            message: 'Payment has been approved',
          })
        )
      }

      /**
       * The default return is vtex.challenge-wait-for-confirmation status, if none of previous ifs is executed
       */
      const response: AuthorizationResponse = await Promise.resolve(
        Authorizations.pending(authorization, {
          delayToCancel: SECONDS_TO_WAIT,
          code: '1234',
          paymentAppData: {
            appName: 'vtex.challenge-wait-for-confirmation',
            payload: JSON.stringify({
              secondsWaiting: SECONDS_TO_WAIT,
            }),
          },
          message: 'vtex.challenge-wait-for-confirmation',
        })
      )

      persistAuthorizationResponse(vbase, response)

      return response
    }

    // To deny payment, use last name as "deny"
    if (authorization.miniCart.buyer.lastName.toLowerCase() === 'deny') {
      return Promise.resolve(
        Authorizations.deny(authorization, {
          message: 'Payment has been denied',
        })
      )
    }

    // This is the default response when using no custom configuration
    return Promise.resolve(
      Authorizations.approve(authorization, {
        tid: randomString(),
        nsu: randomString(),
        authorizationId: randomString(),
        delayToAutoSettle: 3600,
        message: 'Payment has been approved',
      })
    )
  }

  public async cancel(
    cancellation: CancellationRequest
  ): Promise<CancellationResponse> {
    if (this.isTestSuite) {
      return Cancellations.approve(cancellation, {
        cancellationId: randomString(),
      })
    }

    return Promise.resolve(
      Cancellations.approve(cancellation, {
        cancellationId: `foo-${randomString()}`,
        code: 'success',
        message: 'Payment has been canceled.',
      })
    )

    throw new Error('Not implemented')
  }

  public async refund(refund: RefundRequest): Promise<RefundResponse> {
    if (this.isTestSuite) {
      return Refunds.approve(refund, {
        refundId: randomString(),
      })
    }

    if (refund.value === 101010) {
      return Promise.resolve(
        Refunds.manual(refund, {
          // value: 0,
          code: 'foo',
          message: 'Refund should be manually requested',
        })
      )
    }

    // It needs to implement deny scenario

    return Promise.resolve(
      Refunds.approve(refund, {
        refundId: `foo-${randomString()}`,
        code: 'success',
        message: 'Payment has been refunded',
      })
    )

    throw new Error('Not implemented')
  }

  public async settle(
    settlement: SettlementRequest
  ): Promise<SettlementResponse> {
    if (this.isTestSuite) {
      return Settlements.approve(settlement, {
        settleId: randomString(),
      })
    }

    if (settlement.value === 1001) {
      return Promise.resolve(
        Settlements.deny(settlement, {
          code: 'foo',
          message: 'Capture operation has been failed',
        })
      )
    }

    return Promise.resolve(
      Settlements.approve(settlement, {
        settleId: randomString(),
        code: 'success',
        message: 'Payment has been captured',
      })
    )

    throw new Error('Not implemented')
  }

  public inbound: undefined
}
